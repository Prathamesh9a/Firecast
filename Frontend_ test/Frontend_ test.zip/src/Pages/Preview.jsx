import React, { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { useParams } from "react-router-dom";
import { useInView } from "react-intersection-observer";
import io from "socket.io-client";
import {
  FaPlay,
  FaPause,
  FaChevronLeft,
  FaChevronRight,
  FaClock,
} from "react-icons/fa";
import "./preview.css";
import { Clock } from "lucide-react";
import YouTubeLive from "./YouTubeLive";
import WebpageEmbed from "./WebpageEmbed";
import * as pdfjsLib from "pdfjs-dist";
import { useSelector } from 'react-redux';
import axios from "axios";
import Swal from "sweetalert2";

// Set the worker source to the local file in the public folder
pdfjsLib.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.js";

const apiBaseUrl = process.env.REACT_APP_API_BASE_URL || "";
const weatherApiKey = process.env.REACT_APP_WEATHER_API_KEY;
const newsApiKey = process.env.REACT_APP_NEWS_API_KEY;

// Layout options
const layoutOptions = [
  { id: "single", name: "Single View", cols: 1, rows: 1 },
  { id: "2x1", name: "2 Items Horizontal", cols: 2, rows: 1 },
  { id: "1x2", name: "2 Items Vertical", cols: 1, rows: 2 },
  { id: "2x2", name: "4 Items Grid", cols: 2, rows: 2 },
  { id: "3x1", name: "3 Items Horizontal", cols: 3, rows: 1 },
  { id: "1x3", name: "3 Items Vertical", cols: 1, rows: 3 },
];

// Fallback item to prevent blank screen
const fallbackItem = {
  layout: "single",
  time: 10,
  originalIndex: 0,
  content: null,
};

// Default settings if none are provided by the backend
const defaultSettings = {
  ticker: {
    speed: 500,
    height: 48,
    fontSize: 16,
    visible: true,
  },
  dateTime: {
    position: "top-right",
    visible: true,
  },
  temperature: {
    position: "top-left",
    visible: true,
  },
};

// Cache for API responses
const cache = {
  weather: { data: null, timestamp: null, ttl: 15 * 60 * 1000 }, // 15 minutes
  news: { data: null, timestamp: null, ttl: 30 * 60 * 1000 }, // 30 minutes
};

const videoExtensions = [
  { ext: ".mp4", type: "video/mp4" },
  { ext: ".mov", type: "video/quicktime" },
  { ext: ".webm", type: "video/webm" },
];

// Temperature & AQI Component
const TemperatureDisplay = React.memo(({ weather, position, visible }) => {
  if (!visible || !weather) return null;

  const positionClasses = {
    "top-left": "top-4 left-4",
    "top-right": "top-4 right-4",
    "bottom-left": "bottom-4 left-4",
    "bottom-right": "bottom-4 right-4",
  };

  return (
    <div
      className={`absolute ${positionClasses[position] || "bottom-4 left-4"} bg-black bg-opacity-50 text-white p-3 rounded-lg backdrop-blur-sm flex items-center gap-2`}
    >
      <img
        src={`https:${weather.current.condition.icon}`}
        alt="Weather Icon"
        className="w-10 h-10"
      />
      <div>
        <h3 className="text-xl font-semibold">{weather.location.name}</h3>
        <p className="text-lg">
          {weather.current.temp_c}°C | {weather.current.condition.text}
        </p>
        {weather.current.air_quality && (
          <p className="text-sm text-gray-300">
            AQI: {Math.round(weather.current.air_quality.pm2_5)} (PM2.5) |{" "}
            {Math.round(weather.current.air_quality.pm10)} (PM10)
          </p>
        )}
      </div>
    </div>
  );
});

// Fallback UI with blank screen and centered text
const renderFallbackUI = (
  message,
  countdownType,
  timeRemaining,
  formatTimeRemaining
) => (
  <div className="w-full h-full bg-black flex flex-col items-center justify-center">
    <div className="grid grid-cols-1 w-full h-full gap-2 p-2">
      <div className="w-full h-full bg-gray-800 animate-pulse rounded"></div>
    </div>
    <p className="text-white text-2xl font-bold absolute">{message}</p>
    {countdownType === "start" && (
      <div className="flex items-center gap-2 mt-4 absolute">
        <FaClock size={20} className="text-yellow-400 mb-[70%]" />
        <span className="text-xl font-mono text-white mb-[70%]">
          {formatTimeRemaining(timeRemaining)}
        </span>
      </div>
    )}
  </div>
);

// Function to check if the URL is a Power BI URL
const isPowerBIUrl = (url) => {
  return url && url.includes("powerbi.com");
};

const isYouTubeLiveUrl = (url) => {
  if (!url) return false;
  const youtubePatterns = [
    /youtube\.com\/live\/([a-zA-Z0-9_-]+)/,
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)(&|\?).*?\blive\b/,
    /youtube\.com\/channel\/[^/]+\/live/,
    /youtu\.be\/([a-zA-Z0-9_-]+)(\?.*)?\blive\b/,
  ];
  return youtubePatterns.some((pattern) => pattern.test(url));
};

const isYouTubeUrl = (url) => {
  return (
    url &&
    (url.includes("youtube.com/watch") ||
      url.includes("youtube.com/live") ||
      url.includes("youtu.be") ||
      url.includes("youtube.com/embed") ||
      url.includes("youtube.com/v"))
  );
};

const getYouTubeEmbedUrl = (url) => {
  if (!url) return "";
  if (url.includes("youtu.be")) {
    const videoId = url.split("youtu.be/")[1].split(/[?&]/)[0];
    return `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&controls=0`;
  }
  if (url.includes("youtube.com")) {
    const videoIdMatch = url.match(
      /(?:v=|v\/|embed\/|watch\?v=|watch\?.+&v=)([^&?]+)/
    );
    if (videoIdMatch && videoIdMatch[1]) {
      return `https://www.youtube.com/embed/${videoIdMatch[1]}?autoplay=1&mute=1&controls=0`;
    }
  }
  return url;
};

// PageRenderer Component
const PageRenderer = React.memo(({ page, pageNum }) => {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [containerWidth, setContainerWidth] = useState(0);

  const updateWidth = useCallback(() => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setContainerWidth(rect.width);
    } else {
      setContainerWidth(window.innerWidth);
    }
  }, []);

  useEffect(() => {
    updateWidth();
    const resizeObserver = new ResizeObserver(updateWidth);
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }
    window.addEventListener("resize", updateWidth);
    return () => {
      if (containerRef.current) {
        resizeObserver.unobserve(containerRef.current);
      }
      window.removeEventListener("resize", updateWidth);
    };
  }, [updateWidth]);

  useEffect(() => {
    if (
      !canvasRef.current ||
      !page ||
      typeof page.render !== "function" ||
      containerWidth <= 0
    ) {
      console.error(`Invalid page render conditions for page ${pageNum}`, {
        page: !!page,
        render: page?.render,
        containerWidth,
      });
      return;
    }

    console.log(`Rendering PDF page ${pageNum}`);
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");

    const viewport = page.getViewport({ scale: 1.0 });
    const aspectRatio = viewport.width / viewport.height;

    const scale = (containerWidth * window.devicePixelRatio) / viewport.width;
    const scaledViewport = page.getViewport({ scale });

    canvas.width = scaledViewport.width;
    canvas.height = scaledViewport.height;
    canvas.style.width = `${containerWidth}px`;
    canvas.style.height = `${containerWidth / aspectRatio}px`;

    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";

    const renderContext = { canvasContext: context, viewport: scaledViewport };
    let isCancelled = false;
    const renderTask = page.render(renderContext);

    renderTask.promise
      .then(() => console.log(`Successfully rendered page ${pageNum}`))
      .catch((error) => {
        if (!isCancelled) {
          console.error(`Error rendering page ${pageNum}:`, error);
        }
      });

    return () => {
      isCancelled = true;
      if (renderTask.cancel) renderTask.cancel();
    };
  }, [page, pageNum, containerWidth]);

  if (!page || typeof page.render !== "function") {
    return (
      <div className="w-full h-auto bg-gray-900 text-white flex items-center justify-center">
        Wait Your Content Is Loading
      </div>
    );
  }

  return (
    <div ref={containerRef} className="w-full">
      <canvas
        ref={canvasRef}
        className="w-full h-auto"
        key={`page-${pageNum}`}
      />
    </div>
  );
});

// DocumentContent Component
const DocumentContent = React.memo(
  ({ content, summary, getContentUrl, isPaused, originalFormat }) => {
    const fileType = content?.split(".").pop()?.toLowerCase() || "";
    const fileUrl = content ? getContentUrl(content) : "";
    const [pages, setPages] = useState([]);
    const [error, setError] = useState(null);
    const [showSummary, setShowSummary] = useState(!!summary);
    const containerRef = useRef(null);
    const { ref, inView } = useInView({ triggerOnce: false, threshold: 0.5 });

    const toggleSummary = useCallback((e) => {
      e.stopPropagation();
      setShowSummary((prev) => !prev);
    }, []);

    useEffect(() => {
      if (fileType !== "pdf" || !inView || showSummary || !fileUrl) return;

      console.log("Loading PDF:", fileUrl);
      const loadPdf = async () => {
        try {
          const pdf = await pdfjsLib.getDocument(fileUrl).promise;
          console.log("PDF loaded successfully, pages:", pdf.numPages);
          const numPages = pdf.numPages;
          const pageData = [];

          for (let pageNum = 1; pageNum <= numPages; pageNum++) {
            try {
              const page = await pdf.getPage(pageNum);
              const viewport = page.getViewport({ scale: 1.0 });
              console.log(`Page ${pageNum} loaded with viewport:`, viewport);
              pageData.push({ pageNum, viewport, page });
            } catch (pageError) {
              console.error(`Error loading page ${pageNum}:`, pageError);
            }
          }

          if (pageData.length === 0) {
            setError("No valid pages found in PDF");
          } else {
            setPages(pageData);
            setError(null);
          }
        } catch (error) {
          console.error("Error loading PDF:", error);
          setError("Wait Your Content Is Loading");
        }
      };
      loadPdf();
    }, [fileType, fileUrl, inView, showSummary]);

    useEffect(() => {
      if (
        fileType !== "pdf" ||
        !inView ||
        isPaused ||
        !containerRef.current ||
        showSummary
      )
        return;

      console.log(
        `Starting auto-scroll for ${fileType}, isPaused: ${isPaused}`
      );
      const container = containerRef.current;
      const scrollInterval = setInterval(() => {
        if (
          container.scrollTop + container.clientHeight >=
          container.scrollHeight
        ) {
          console.log("Reached bottom, resetting to top");
          container.scrollTo({ top: 0, behavior: "smooth" });
        } else {
          container.scrollBy({ top: 1, behavior: "auto" });
        }
      }, 50);

      return () => {
        console.log("Cleaning up scroll interval");
        clearInterval(scrollInterval);
      };
    }, [fileType, inView, isPaused, showSummary]);

    const cleanedSummary = summary
      ? summary.replace(/<think>[\s\S]*<\/think>/g, "").trim()
      : null;

    if (cleanedSummary && showSummary) {
      return (
        <div className="relative w-full h-screen">
          <div className="w-full h-screen overflow-y-auto scrollbar-hidden bg-gray-900 p-8">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-2xl font-bold mb-6 text-white">
                Document Summary
              </h2>
              <div className="prose prose-lg prose-invert">
                <div
                  dangerouslySetInnerHTML={{ __html: cleanedSummary }}
                  className="text-white"
                />
              </div>
            </div>
          </div>
          <button
            onClick={toggleSummary}
            className="absolute top-[13%] right-3 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md shadow-lg z-10"
          >
            View Full Document
          </button>
        </div>
      );
    }

    if (fileType === "pdf") {
      return (
        <div className="relative w-full h-screen">
          <div
            ref={(node) => {
              containerRef.current = node;
              ref(node);
            }}
            className="w-full h-screen overflow-y-auto scrollbar-hidden"
            style={{ scrollBehavior: "smooth" }}
          >
            {inView ? (
              <div className="w-full min-h-screen flex flex-col items-center bg-gray-900">
                {error ? (
                  <div className="w-full h-screen flex items-center justify-center text-white">
                    {error}
                  </div>
                ) : pages.length > 0 ? (
                  <>
                    {pages.map((page) => (
                      <div
                        key={`page-container-${page.pageNum}`}
                        className="w-full mb-4"
                      >
                        <PageRenderer
                          page={page.page}
                          pageNum={page.pageNum}
                        />
                      </div>
                    ))}
                  </>
                ) : (
                  <div className="w-full h-screen flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-white"></div>
                  </div>
                )}
              </div>
            ) : (
              <div className="w-full h-screen bg-gray-900 flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-white"></div>
              </div>
            )}
          </div>
          {cleanedSummary && (
            <button
              onClick={toggleSummary}
              className="absolute top-[13%] right-3 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md shadow-lg z-10"
            >
              View Summary
            </button>
          )}
        </div>
      );
    }

    return (
      <div className="relative w-full h-screen">
        <div
          ref={(node) => {
            containerRef.current = node;
            ref(node);
          }}
          className="w-full h-screen overflow-y-auto scrollbar-hidden"
          style={{ scrollBehavior: "smooth" }}
        >
          {inView ? (
            <div className="w-full h-screen flex items-center justify-center text-white bg-gray-900">
              <div className="text-center">
                <p className="text-xl font-semibold mb-2">
                  Wait Your Content Is Loading
                </p>
                <p className="text-lg">
                  The document may not have been converted to PDF correctly.
                  Please contact support.
                </p>
              </div>
            </div>
          ) : (
            <div className="w-full h-screen bg-gray-900 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-white"></div>
            </div>
          )}
        </div>
        {cleanedSummary && (
          <button
            onClick={toggleSummary}
            className="absolute top-[13%] right-3 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md shadow-lg z-10"
          >
            View Summary
          </button>
        )}
      </div>
    );
  }
);

// MediaItem Component
const MediaItem = React.memo(
  ({
    content,
    index,
    isPaused,
    setProgress,
    getContentUrl,
    isWebpageUrl,
    videoRefs,
  }) => {
    const { ref, inView } = useInView({ triggerOnce: true });
    const videoRef = useRef(null);
    const [error, setError] = useState(null);
    const [fallbackSrc, setFallbackSrc] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [videoReady, setVideoReady] = useState(false);
    const [requiresInteraction, setRequiresInteraction] = useState(false);
    const timeoutRef = useRef(null);
    const lastUpdateRef = useRef(0);
    const throttleInterval = 500;
    const hasResetRef = useRef(false);

    useEffect(() => {
      if (
        videoRef.current &&
        content?.content &&
        videoExtensions.some((video) =>
          content.content.toLowerCase().endsWith(video.ext)
        )
      ) {
        videoRefs.current[index] = videoRef.current;
      }
      return () => {
        if (videoRefs.current[index]) {
          delete videoRefs.current[index];
        }
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }
      };
    }, [index, videoRefs, content]);

    const handleTimeUpdate = useCallback((e) => {
      const now = Date.now();
      if (now - lastUpdateRef.current >= throttleInterval) {
        setProgress((e.target.currentTime / e.target.duration) * 100);
        lastUpdateRef.current = now;
      }

      const video = e.target;
      if (video.duration - video.currentTime <= 1.0 && !isPaused && !hasResetRef.current) {
        hasResetRef.current = true;
        video.pause();
        video.currentTime = 0;
        setTimeout(() => {
          if (!isPaused) {
            video.play().catch((err) => {
              console.error("Error replaying video on pre-emptive reset:", err);
              setError({
                message: `Failed to replay video: ${err.message}`,
                details: {
                  code: err.code || "N/A",
                  userAgent: navigator.userAgent,
                },
              });
            });
          }
          hasResetRef.current = false;
        }, 200);
      }
    }, [setProgress, isPaused]);

    const handleManualPlay = () => {
      if (videoRef.current) {
        videoRef.current.play().then(() => {
          setRequiresInteraction(false);
          setError(null);
          console.log("Video started after user interaction");
        }).catch((err) => {
          console.error("Manual play failed:", err);
          setError({
            message: `Failed to play video: ${err.message}`,
            details: {
              code: err.code || "N/A",
              userAgent: navigator.userAgent,
            },
          });
        });
      }
    };

    const handleError = useCallback((e) => {
      const video = videoRef.current;
      const errorDetails = {
        message: e.target.error?.message || "Unknown video error",
        code: e.target.error?.code || "N/A",
        userAgent: navigator.userAgent,
        src: e.target.currentSrc,
      };

      if (video && video.currentTime >= video.duration - 0.1) {
        console.warn("End of video reached. Reloading video source:", errorDetails);
        try {
          const currentSrc = video.currentSrc || video.src;
          if (!currentSrc) {
            throw new Error("No video source found to reload.");
          }
          video.pause();
          video.src = '';
          video.load();
          video.src = currentSrc;
          video.load();
          if (!isPaused) {
            video.play().catch((err) => {
              console.error("Failed to autoplay after reload:", err);
              setError({
                message: `Failed to replay video after reload: ${err.message}`,
                details: {
                  code: err.code || "N/A",
                  userAgent: navigator.userAgent,
                },
              });
            });
          }
        } catch (err) {
          console.error("Video reload error:", err);
          setError({
            message: `Error while reloading video: ${err.message}`,
            details: {
              userAgent: navigator.userAgent,
            },
          });
        }
        return;
      }

      console.error("Video error:", errorDetails);
      setIsLoading(false);
      setVideoReady(false);
      setError({
        message: `Video failed to load`,
        details: errorDetails,
      });
    }, [isPaused]);

    useEffect(() => {
      if (
        !videoRef.current ||
        !inView ||
        !content?.content ||
        !videoExtensions.some((video) =>
          content.content.toLowerCase().endsWith(video.ext)
        )
      ) {
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      setVideoReady(false);
      const video = videoRef.current;

      const attemptToPlayVideo = () => {
        if (!video) return;
        video.play().then(() => {
          setIsLoading(false);
        }).catch((err) => {
          console.error("Playback failed:", err);
          setIsLoading(false);
          if (err.name === "NotAllowedError") {
            setRequiresInteraction(true);
            setError({
              message: "Autoplay blocked: User interaction required",
              details: {
                code: "NotAllowedError",
                userAgent: navigator.userAgent,
              },
            });
          } else {
            setError({
              message: `Video playback failed: ${err.message}`,
              details: {
                code: err.code || "N/A",
                userAgent: navigator.userAgent,
              },
            });
          }
        });
      };

      const handleCanPlay = () => {
        if (!video) return;
        console.log(`Video can play: ${video.src}`);
        setVideoReady(true);
        setError(null);
        if (!isPaused && !requiresInteraction) {
          attemptToPlayVideo();
        } else {
          setIsLoading(false);
        }
      };

      video.addEventListener("canplay", handleCanPlay);
      video.addEventListener("loadeddata", handleCanPlay);
      video.addEventListener("error", handleError);
      video.addEventListener("timeupdate", handleTimeUpdate);

      const handlePlaying = () => {
        console.log("Video is now playing");
        setIsLoading(false);
      };
      video.addEventListener("playing", handlePlaying);

      video.load();

      if (isPaused) {
        video.pause();
      } else if (videoReady && !error && !requiresInteraction) {
        video.play().catch((err) => {
          console.error("Initial playback failed:", err);
          if (err.name === "NotAllowedError") {
            setRequiresInteraction(true);
            setError({
              message: "Autoplay blocked: User interaction required",
              details: {
                code: "NotAllowedError",
                userAgent: navigator.userAgent,
              },
            });
          }
        });
      }

      return () => {
        video.removeEventListener("canplay", handleCanPlay);
        video.removeEventListener("loadeddata", handleCanPlay);
        video.removeEventListener("error", handleError);
        video.removeEventListener("timeupdate", handleTimeUpdate);
        video.removeEventListener("playing", handlePlaying);
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }
      };
    }, [isPaused, inView, index, content, fallbackSrc, requiresInteraction, handleTimeUpdate, handleError]);

    if (!content || !content.content) {
      console.warn(`MediaItem: No content provided for index ${index}`, {
        content,
      });
      return (
        <div className="w-full h-full flex items-center justify-center text-white bg-gray-900">
          <p>No content available for this item.</p>
        </div>
      );
    }

    const contentUrl = getContentUrl(content.content);

    if (isPowerBIUrl(content.content)) {
      return (
        <iframe
          src={contentUrl}
          className="w-full h-full"
          title="Embedded Power BI Report"
          frameBorder="0"
          allowFullScreen
        />
      );
    } else if (isWebpageUrl(content.content)) {
      return <WebpageEmbed webpageUrl={contentUrl} />;
    } else if (
      videoExtensions.some((video) =>
        content.content.toLowerCase().endsWith(video.ext)
      )
    ) {
      const originalSrc = contentUrl;
      const isMov = content.content.toLowerCase().endsWith(".mov");
      const isWebm = content.content.toLowerCase().endsWith(".webm");
      const videoSrc = fallbackSrc || originalSrc;

      return (
        <div ref={ref} className="w-full h-full relative">
          {inView ? (
            <>
              <video
                ref={videoRef}
                autoPlay={!isPaused}
                muted
                className={`w-full h-full object-contain ${isLoading ? 'opacity-0' : 'opacity-100'}`}
                style={{ transition: 'opacity 0.3s ease' }}
              >
                <source
                  src={videoSrc}
                  type={
                    videoSrc.toLowerCase().endsWith(".mp4")
                      ? "video/mp4"
                      : isMov
                        ? "video/quicktime"
                        : "video/webm"
                  }
                />
                Your browser does not support the video tag.
              </video>

              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 bg-opacity-80">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-white"></div>
                </div>
              )}

              {error && !isLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-gray-900 p-4 text-center">
                  <p className="text-lg font-semibold">{error.message}</p>
                  {error.details && (
                    <p className="text-sm text-gray-400 mt-2">
                      Error Code: {error.details.code}
                      <br />
                      Browser: {error.details.userAgent}
                    </p>
                  )}
                  {requiresInteraction && (
                    <button
                      onClick={handleManualPlay}
                      className="mt-4 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md shadow-lg flex items-center gap-2"
                    >
                      <FaPlay size={20} />
                      Play Video
                    </button>
                  )}
                  {content.thumbnail && (
                    <img
                      src={getContentUrl(content.thumbnail)}
                      alt="Video fallback"
                      className="mt-4 max-w-full max-h-64 object-contain"
                    />
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="w-full h-full bg-gray-900 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-white"></div>
            </div>
          )}
        </div>
      );
    } else if (content.content.endsWith(".pdf")) {
      return (
        <DocumentContent
          content={content.content}
          summary={content.summary}
          getContentUrl={getContentUrl}
          isPaused={isPaused}
          originalFormat={content.originalFormat}
        />
      );
    } else if (isYouTubeUrl(content.content)) {
      return (
        <div ref={ref} className="w-full h-full">
          {inView ? (
            <YouTubeLive
              liveUrl={contentUrl}
              isPaused={isPaused}
              inView={inView}
              showControls={false}
            />
          ) : (
            <div className="w-full h-full bg-gray-900 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-white"></div>
            </div>
          )}
        </div>
      );
    } else {
      return (
        <div ref={ref} className="w-full h-full relative">
          {inView ? (
            <>
              <img
                src={contentUrl}
                alt="Preview content"
                className={`w-full h-full object-contain ${isLoading ? 'opacity-0' : 'opacity-100'}`}
                loading="lazy"
                style={{ transition: 'opacity 0.3s ease' }}
                onLoad={() => setIsLoading(false)}
                onError={(e) => {
                  console.error("Image load error:", {
                    src: e.target.src,
                    content: content.content,
                  });
                  setIsLoading(false);
                  setError({
                    message: "Image failed to load",
                    details: {
                      code: "N/A",
                      userAgent: navigator.userAgent,
                    },
                  });
                }}
              />
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 bg-opacity-80">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-white"></div>
                </div>
              )}
              {error && !isLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-gray-900 p-4 text-center">
                  <p className="text-lg font-semibold">{error.message}</p>
                  {error.details && (
                    <p className="text-sm text-gray-400 mt-2">
                      Error Code: {error.details.code}
                      <br />
                      Browser: {error.details.userAgent}
                    </p>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="w-full h-full bg-gray-900 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-white"></div>
            </div>
          )}
        </div>
      );
    }
  }
);

// Clock Component
const ClockDisplay = React.memo(({ position = "top-right", visible = true }) => {
  const [dateTime, setDateTime] = useState(new Date());
  const [locationName, setLocationName] = useState("Your Location");
  const [userTimeZone, setUserTimeZone] = useState(Intl.DateTimeFormat().resolvedOptions().timeZone);

  useEffect(() => {
    const fetchLocationTimeZone = async () => {
      try {
        const position = await getCurrentPosition();
        if (position) {
          const res = await axios.get(
            `https://api.weatherapi.com/v1/current.json?key=${weatherApiKey}&q=${position.latitude},${position.longitude}&aqi=no`
          );
          const { location: weatherLocation } = res.data;
          setLocationName(`${weatherLocation.name}, ${weatherLocation.region}`);
          setUserTimeZone(weatherLocation.tz_id);
        } else {
          const res = await axios.get(
            `https://api.weatherapi.com/v1/current.json?key=${weatherApiKey}&q=auto:ip&aqi=no`
          );
          const { location } = res.data;
          setLocationName(`${location.name}, ${location.region} (IP-based)`);
          setUserTimeZone(location.tz_id);
        }
      } catch (error) {
        console.error("Failed to fetch location from WeatherAPI:", error.message);
        setLocationName("Your Location");
      }
    };

    if (weatherApiKey) {
      fetchLocationTimeZone();
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setDateTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (!visible) return null;

  const positionClasses = {
    "top-left": "top-4 left-4",
    "top-right": "top-4 right-4",
    "bottom-left": "bottom-4 left-4",
    "bottom-right": "bottom-4 right-4",
  };

  return (
    <div
      className={`absolute ${positionClasses[position] || "top-4 right-4"} flex items-center gap-3 bg-gradient-to-r from-gray-600 to-gray-700 text-white px-4 py-2 rounded-xl shadow-lg backdrop-blur-lg`}
    >
      <Clock className="w-6 h-6 text-yellow-400" />
      <div className="text-right">
        <p className="text-sm font-medium opacity-80">
          {dateTime
            .toLocaleDateString("en-IN", {
              weekday: "short",
              day: "2-digit",
              month: "short",
              year: "numeric",
              timeZone: userTimeZone,
            })
            .toUpperCase()}
        </p>
        <p className="text-xl font-bold tracking-wider">
          {dateTime.toLocaleTimeString("en-IN", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: true,
            timeZone: userTimeZone,
          })}
        </p>
      </div>
    </div>
  );
});

// Helper function to get accurate geolocation
const getCurrentPosition = () => {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      console.warn("Geolocation is not supported by this browser");
      resolve(null);
      return;
    }

    const options = {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 300000
    };

    navigator.geolocation.getCurrentPosition(
      (position) => {
        console.log("Geolocation success:", {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy
        });
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        });
      },
      (error) => {
        console.warn("Geolocation error:", error.message);
        resolve(null);
      },
      options
    );
  });
};

const Preview = () => {
  const { url } = useParams();
  const mediaItems = useSelector((state) => state.media.mediaItems);
  const [mediaContent, setMediaContent] = useState([]);
  const [isEnabled, setIsEnabled] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [progress, setProgress] = useState(0);
  const videoRefs = useRef({});
  const [currentLayout, setCurrentLayout] = useState("single");
  const [visibleItems, setVisibleItems] = useState([fallbackItem]);
  const [activeSlideshow, setActiveSlideshow] = useState(false);
  const [scheduledAt, setScheduledAt] = useState(null);
  const [expiresAt, setExpiresAt] = useState(null);
  const [timeRemaining, setTimeRemaining] = useState(null);
  const [countdownType, setCountdownType] = useState(null);
  const [weather, setWeather] = useState(null);
  const [news, setNews] = useState([]);
  const [customTicker, setCustomTicker] = useState(null);
  const [allContent, setAllContent] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [settings, setSettings] = useState(defaultSettings);
  const [isSessionActive, setIsSessionActive] = useState(true); // NEW: Persistent flag to prevent reconnection after replacement
  const controlTimeoutRef = useRef(null);
  const socketRef = useRef(null);
  const pollingRef = useRef(null);
  const lastFetchRef = useRef(0);

  const resetControlTimeout = useCallback(() => {
    if (controlTimeoutRef.current) {
      clearTimeout(controlTimeoutRef.current);
    }
    setShowControls(true);
    controlTimeoutRef.current = setTimeout(() => {
      setShowControls(false);
    }, 5000);
  }, []);

  const togglePlayPause = useCallback(() => {
    setIsPaused((prev) => {
      console.log(`Toggling slideshow to ${!prev ? "paused" : "playing"}`);
      const newPausedState = !prev;
      Object.values(videoRefs.current).forEach((video) => {
        if (video) {
          if (newPausedState) {
            video.pause();
          } else {
            video.play().catch((err) => {
              console.error("Error playing video:", err);
            });
          }
        }
      });
      return newPausedState;
    });
    resetControlTimeout();
  }, [resetControlTimeout]);

  const formatTimeRemaining = useCallback((milliseconds) => {
    if (milliseconds <= 0) return "00:00:00";
    const totalSeconds = Math.floor(milliseconds / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  }, []);

  const formatDescription = useCallback((description) => {
    if (!description) return "";
    return description.replace(/<[^>]*>/g, "");
  }, []);

  const isTimeWindowActive = useCallback((timeWindow) => {
    if (!timeWindow || !timeWindow.startTime || !timeWindow.endTime) {
      console.warn("Invalid time window, treated as always active:", timeWindow);
      return true;
    }

    const timeFormat = /^([0-1][0-9]|2[0-3]):[0-5][0-9]$/;
    if (
      !timeFormat.test(timeWindow.startTime) ||
      !timeFormat.test(timeWindow.endTime)
    ) {
      console.error("Malformed time format, skipping:", timeWindow);
      return false;
    }

    const now = new Date();
    const nowTime = now.getHours() * 60 + now.getMinutes();
    const startTimeParts = timeWindow.startTime.split(":");
    const endTimeParts = timeWindow.endTime.split(":");
    const startMinutes =
      parseInt(startTimeParts[0]) * 60 + parseInt(startTimeParts[1]);
    const endMinutes =
      parseInt(endTimeParts[0]) * 60 + parseInt(endTimeParts[1]);

    return nowTime >= startMinutes && nowTime <= endMinutes;
  }, []);

  const isScheduledNow = useCallback(
    (schedule) => {
      if (!schedule || Object.keys(schedule).length === 0) {
        console.log("No schedule provided, content is always active");
        return true;
      }

      if (
        !schedule.startTime &&
        !schedule.endTime &&
        !schedule.startDate &&
        !schedule.endDate &&
        (!schedule.timeWindows || schedule.timeWindows.length === 0)
      ) {
        console.log("No scheduling restrictions, content is always active");
        return true;
      }

      const now = new Date();
      const today = now.toISOString().split("T")[0];

      let isWithinDate = true;
      if (schedule.startDate) {
        const startDate = schedule.startDate.split("T")[0];
        isWithinDate = today >= startDate;
      }
      if (schedule.endDate) {
        const endDate = schedule.endDate.split("T")[0];
        isWithinDate = isWithinDate && today <= endDate;
      }

      if (!isWithinDate) {
        console.log("Content outside date range:", {
          today,
          startDate: schedule.startDate,
          endDate: schedule.endDate,
        });
        return false;
      }

      let isWithinTimeWindow = false;
      if (schedule.timeWindows && schedule.timeWindows.length > 0) {
        isWithinTimeWindow = schedule.timeWindows.some((timeWindow) => {
          const isActive = isTimeWindowActive(timeWindow);
          return isActive;
        });
      } else if (schedule.startTime && schedule.endTime) {
        const nowTime = now.getHours() * 60 + now.getMinutes();
        const startTimeParts = schedule.startTime.split(":");
        const endTimeParts = schedule.endTime.split(":");
        const startMinutes =
          parseInt(startTimeParts[0]) * 60 + parseInt(startTimeParts[1]);
        const endMinutes =
          parseInt(endTimeParts[0]) * 60 + parseInt(endTimeParts[1]);
        isWithinTimeWindow = nowTime >= startMinutes && nowTime <= endMinutes;
        console.log("Legacy time check:", {
          startTime: schedule.startTime,
          endTime: schedule.endTime,
          isWithinTimeWindow,
        });
      } else {
        isWithinTimeWindow = true;
      }

      return isWithinDate && isWithinTimeWindow;
    },
    [isTimeWindowActive]
  );

  const groupMediaByLayout = useCallback((content) => {
    const groupedContent = {};
    (content || []).forEach((item, index) => {
      const layoutKey = item?.layout || "single";
      if (!groupedContent[layoutKey]) {
        groupedContent[layoutKey] = [];
      }
      groupedContent[layoutKey].push({ ...item, originalIndex: index });
    });
    return groupedContent;
  }, []);

  const getActiveContent = useCallback(
    (content) => {
      if (!Array.isArray(content)) {
        console.warn("Invalid content array, returning empty:", content);
        return [];
      }

      const priorityOrder = { high: 3, medium: 2, low: 1 };

      const exclusiveHighPriorityContent = content.filter(
        (item) =>
          item?.schedule &&
          isScheduledNow(item.schedule) &&
          item.schedule.displayMode === "exclusive" &&
          item.schedule.priority === "high"
      );

      if (exclusiveHighPriorityContent.length > 0) {
        exclusiveHighPriorityContent.forEach((item) => {
          if (
            (!item.schedule.timeWindows ||
              item.schedule.timeWindows.every(
                (tw) => !tw.startTime || !tw.endTime
              )) &&
            !item.schedule.startDate &&
            !item.schedule.endDate &&
            !item.schedule.startTime &&
            !item.schedule.endTime
          ) {
            console.warn(
              "Exclusive high-priority content has no time restrictions, may override others:",
              item
            );
          }
        });
        console.log(
          "Exclusive high-priority content active:",
          exclusiveHighPriorityContent
        );
        return exclusiveHighPriorityContent.sort((a, b) => {
          const priorityA = priorityOrder[a.schedule?.priority || "low"] || 0;
          const priorityB = priorityOrder[b.schedule?.priority || "low"] || 0;
          return priorityB - priorityA;
        });
      }

      const activeContent = content.filter(
        (item) => item?.schedule && isScheduledNow(item.schedule)
      );

      return activeContent.sort((a, b) => {
        const priorityA = priorityOrder[a.schedule?.priority || "low"] || 0;
        const priorityB = priorityOrder[b.schedule?.priority || "low"] || 0;
        return priorityB - priorityA;
      });
    },
    [isScheduledNow]
  );

  const stableCacheBuster = useMemo(() => Date.now(), []);

  const getContentUrl = useCallback(
    (content) => {
      if (!content) return "";

      const prefix = "/api/upload/preview/";
      let baseUrl;

      if (content.startsWith(prefix)) {
        baseUrl = content.slice(prefix.length);
      } else if (isYouTubeUrl(content)) {
        return getYouTubeEmbedUrl(content);
      } else {
        baseUrl = content.startsWith("http")
          ? content
          : `${apiBaseUrl}/${content}`;
      }

      const cacheBusterValue = url === "Automate" ? stableCacheBuster : "static";
      const cacheBusterParam = `t=${cacheBusterValue}`;
      const separator = baseUrl.includes("?") ? "&" : "?";

      return `${baseUrl}${separator}${cacheBusterParam}`;
    },
    [url, stableCacheBuster]
  );

  const preloadMedia = useCallback(
    (content) => {
      (content || []).slice(0, 3).forEach((item) => {
        if (item?.content) {
          const url = getContentUrl(item.content);
          const link = document.createElement("link");
          link.rel = "preload";
          link.href = url;
          link.as = videoExtensions.some((video) =>
            item.content.toLowerCase().endsWith(video.ext)
          )
            ? "video"
            : item.content.endsWith(".pdf")
              ? "fetch"
              : "image";
          link.onerror = () => console.error(`Wait Your Content Is Loading ${url}`);
          document.head.appendChild(link);
        }
      });
    },
    [getContentUrl]
  );

  const fetchWeather = useCallback(
    async (location = "Ohio") => {
      if (!weatherApiKey) {
        console.error("Weather API key is missing.");
        return;
      }

      const now = Date.now();
      if (
        cache.weather.data &&
        cache.weather.timestamp &&
        now - cache.weather.timestamp < cache.weather.ttl
      ) {
        setWeather(cache.weather.data);
        return;
      }

      try {
        let weatherLocation = location;
        if (location === "auto" || location === "Ohio") {
          const position = await getCurrentPosition();
          if (position) {
            weatherLocation = `${position.latitude},${position.longitude}`;
            console.log("Using accurate coordinates for weather:", weatherLocation);
          } else {
            weatherLocation = "auto:ip";
            console.log("Falling back to IP-based location for weather");
          }
        }

        const url = `https://api.weatherapi.com/v1/current.json?key=${weatherApiKey}&q=${weatherLocation}&aqi=no`;
        const response = await axios.get(url, { timeout: 8000 });
        cache.weather.data = response.data;
        cache.weather.timestamp = now;
        setWeather(response.data);
      } catch (error) {
        console.error("Error fetching weather:", error);
      }
    },
    []
  );

  const getUserLocation = useCallback(() => {
    getCurrentPosition().then((position) => {
      if (position) {
        fetchWeather(`${position.latitude},${position.longitude}`);
      } else {
        console.log("Using IP-based location as fallback");
        fetchWeather("auto:ip");
      }
    });
  }, [fetchWeather]);

  const fetchNews = useCallback(async () => {
    const now = Date.now();
    if (
      cache.news.data &&
      cache.news.timestamp &&
      now - cache.news.timestamp < cache.news.ttl
    ) {
      setNews(cache.news.data);
      return;
    }
    try {
      const feeds = [
        "https://rss.cnn.com/rss/edition.rss",
        "https://feeds.nbcnews.com/nbcnews/public/news",
        "https://feeds.washingtonpost.com/rss/national",
        "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",
        "https://feeds.reuters.com/reuters/topNews",
        "https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml",
        "https://feeds.abcnews.go.com/abcnews/topstories",
        "https://feeds.foxnews.com/foxnews/latest",
      ];
      const responses = await Promise.all(
        feeds.map((feed) =>
          axios
            .get(
              `${apiBaseUrl}/api/upload/parse-rss?url=${encodeURIComponent(
                feed
              )}`,
              { timeout: 5000 }
            )
            .then((res) => res.data.items || [])
            .catch(() => [])
        )
      );
      const rssArticles = responses.flat().slice(0, 8);
      let articles = rssArticles;
      if (rssArticles.length === 0 && newsApiKey) {
        const fallbackResponse = await axios.get(
          `https://gnews.io/api/v4/top-headlines?country=in&token=${newsApiKey}`,
          { timeout: 5000 }
        );
        articles = fallbackResponse.data.articles.slice(0, 8);
      }
      cache.news.data = articles;
      cache.news.timestamp = now;
      setNews(articles);
    } catch (error) {
      console.error("Error fetching news:", error);
      setNews([]);
    }
  }, []);

  const updateVisibleItems = useCallback(
    (layout, groupedContent, index) => {
      const layoutConfig =
        layoutOptions.find((option) => option.id === layout) ||
        layoutOptions[0];
      const itemsPerPage = layoutConfig.cols * layoutConfig.rows;
      const allItems =
        mediaContent.length > 0
          ? mediaContent.map((item, idx) => ({ ...item, originalIndex: idx }))
          : [fallbackItem];

      if (index >= allItems.length || index < 0) {
        console.warn("Index out of bounds, using fallback", {
          index,
          total: allItems.length,
        });
        setVisibleItems([fallbackItem]);
        return;
      }

      const currentItem = allItems[index] || fallbackItem;
      const currentLayout = currentItem.layout || "single";
      setCurrentLayout(currentLayout);

      if (currentLayout !== layout) {
        setCurrentLayout(currentLayout);
      }

      const start = index;
      const end = Math.min(start + itemsPerPage, allItems.length);
      const itemsToDisplay = allItems.slice(start, end);
      setVisibleItems(
        itemsToDisplay.length > 0 ? itemsToDisplay : [fallbackItem]
      );
    },
    [mediaContent]
  );

  const isWebpageUrl = useCallback(
    (url) => {
      if (!url) return false;
      const excludedExtensions = [
        ...videoExtensions.map((video) => video.ext),
        ".pdf",
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
      ];
      const hasExcludedExtension = excludedExtensions.some((ext) =>
        url.toLowerCase().endsWith(ext)
      );
      const isSpecialUrl = isPowerBIUrl(url) || isYouTubeLiveUrl(url);
      return (
        (url.startsWith("http://") || url.startsWith("https://")) &&
        !isSpecialUrl &&
        !hasExcludedExtension
      );
    },
    []
  );

  const getGridClasses = useCallback(() => {
    switch (currentLayout) {
      case "2x1":
        return "grid-cols-2 grid-rows-1";
      case "1x2":
        return "grid-cols-1 grid-rows-2";
      case "2x2":
        return "grid-cols-2 grid-rows-2";
      case "3x1":
        return "grid-cols-3 grid-rows-1";
      case "1x3":
        return "grid-cols-1 grid-rows-3";
      case "single":
      default:
        return "grid-cols-1 grid-rows-1";
    }
  }, [currentLayout]);

  const isAnyPowerBIContent = useCallback(() => {
    return visibleItems.some(
      (item) => item?.content && isPowerBIUrl(item.content)
    );
  }, [visibleItems]);

  const goNext = useCallback(() => {
    const currentItem = mediaContent[currentIndex] || fallbackItem;
    const layoutConfig =
      layoutOptions.find((option) => option.id === (currentItem.layout || "single")) ||
      layoutOptions[0];
    const itemsPerPage = layoutConfig.cols * layoutConfig.rows;
    const nextIndex = currentIndex + itemsPerPage;
    const groupedContent = groupMediaByLayout(
      mediaContent.length > 0 ? mediaContent : [fallbackItem]
    );
    if (nextIndex >= mediaContent.length && mediaContent.length > 0) {
      setCurrentIndex(0);
      const firstLayout = mediaContent[0]?.layout || "single";
      setCurrentLayout(firstLayout);
      updateVisibleItems(firstLayout, groupedContent, 0);
    } else if (mediaContent.length === 0) {
      setVisibleItems([fallbackItem]);
    } else {
      setCurrentIndex(nextIndex);
      const nextItem = mediaContent[nextIndex] || fallbackItem;
      const nextLayout = nextItem.layout || "single";
      setCurrentLayout(nextLayout);
      updateVisibleItems(nextLayout, groupedContent, nextIndex);
    }
    setShowControls(true);
    resetControlTimeout();
  }, [
    mediaContent,
    currentIndex,
    groupMediaByLayout,
    updateVisibleItems,
    resetControlTimeout,
  ]);

  const goPrev = useCallback(() => {
    const currentItem = mediaContent[currentIndex] || fallbackItem;
    const layoutConfig =
      layoutOptions.find((option) => option.id === (currentItem.layout || "single")) ||
      layoutOptions[0];
    const itemsPerPage = layoutConfig.cols * layoutConfig.rows;
    const prevIndex = Math.max(0, currentIndex - itemsPerPage);
    const groupedContent = groupMediaByLayout(
      mediaContent.length > 0 ? mediaContent : [fallbackItem]
    );
    setCurrentIndex(prevIndex);
    const prevItem = mediaContent[prevIndex] || fallbackItem;
    const prevLayout = prevItem.layout || "single";
    setCurrentLayout(prevLayout);
    updateVisibleItems(prevLayout, groupedContent, prevIndex);
    setShowControls(true);
    resetControlTimeout();
  }, [
    mediaContent,
    currentIndex,
    groupMediaByLayout,
    updateVisibleItems,
    resetControlTimeout,
  ]);

  const fetchData = useCallback(async (source = "unknown") => {
    const now = Date.now();
    const minInterval = 60 * 1000; // 1 minute
    if (now - lastFetchRef.current < minInterval) {
      console.log(`fetchData throttled (source: ${source})`);
      return;
    }
    lastFetchRef.current = now;

    setIsLoading(true);
    try {
      const response = await axios.post(`${apiBaseUrl}/api/upload/preview/${url}`, { timeout: 10000 });
      if (response.data) {
        const cacheKey = `preview_${url}`;
        localStorage.setItem(cacheKey, JSON.stringify(response.data));
        const content = response.data.url_content || [];
        setAllContent(content);
        const activeContent = getActiveContent(content);
        setMediaContent(activeContent);
        console.log("Fetched content:", activeContent);
        if (activeContent.length > 0) {
          setCurrentIndex(0);
          const firstLayout = activeContent[0].layout || "single";
          setCurrentLayout(firstLayout);
          const groupedContent = groupMediaByLayout(activeContent);
          updateVisibleItems(firstLayout, groupedContent, 0);
          preloadMedia(activeContent);
        } else {
          console.warn("No active content available, using fallback");
          setVisibleItems([fallbackItem]);
        }
        const isUrlEnabled = response.data.isEnabled === true;
        setIsEnabled(isUrlEnabled);
        setScheduledAt(
          response.data.scheduledAt ? new Date(response.data.scheduledAt) : null
        );
        setExpiresAt(
          response.data.expiresAt ? new Date(response.data.expiresAt) : null
        );
        setCustomTicker(response.data.custom_ticker || null);
        setSettings(response.data.settings || defaultSettings);
      } else {
        console.warn("No data in response, using fallback");
        setVisibleItems([fallbackItem]);
      }
    } catch (error) {
      console.error(`Error fetching preview content (source: ${source}):`, error);
      setVisibleItems([fallbackItem]);
    } finally {
      setIsLoading(false);
    }
  }, [url, getActiveContent, groupMediaByLayout, preloadMedia, updateVisibleItems]);

  const handleSocketUpdate = useCallback((data, eventType) => {
    if (!data || !data.url_content) {
      console.warn(`Invalid ${eventType} data received:`, data);
      setVisibleItems([fallbackItem]);
      return;
    }

    const cacheKey = `preview_${url}`;
    localStorage.setItem(cacheKey, JSON.stringify(data));
    const content = data.url_content || [];
    setAllContent(content);
    const activeContent = getActiveContent(content);
    setMediaContent(activeContent);
    const isUrlEnabled = data.isEnabled === true;
    setIsEnabled(isUrlEnabled);
    setScheduledAt(data.scheduledAt ? new Date(data.scheduledAt) : null);
    setExpiresAt(data.expiresAt ? new Date(data.expiresAt) : null);
    setCustomTicker(data.custom_ticker || null);
    setSettings(data.settings || defaultSettings);

    if (activeContent.length > 0) {
      setCurrentIndex(0);
      const firstLayout = activeContent[0].layout || "single";
      setCurrentLayout(firstLayout);
      const groupedContent = groupMediaByLayout(activeContent);
      updateVisibleItems(firstLayout, groupedContent, 0);
      preloadMedia(activeContent);
    } else {
      console.warn(`No active content for ${eventType}, using fallback`);
      setVisibleItems([fallbackItem]);
    }
    setIsLoading(false);
    console.log(`Processed ${eventType} event:`, activeContent);
  }, [url, getActiveContent, groupMediaByLayout, updateVisibleItems, preloadMedia]);

  const connectSocket = useCallback(() => {
    if (!isSessionActive) {
      console.log('Session is inactive (replaced), skipping connection attempt');
      return; // NEW: Block any further connection attempts
    }

    // Disconnect existing socket properly
    if (socketRef.current) {
      console.log("Socket already exists, disconnecting previous...");
      socketRef.current.isBeingReplaced = false; // Reset replacement flag
      socketRef.current.removeAllListeners(); // Remove all listeners first
      socketRef.current.disconnect();
      socketRef.current = null;
    }

    const socket = io(apiBaseUrl, {
      query: { url },
      auth: { token: localStorage.getItem('jwt_token') },
      reconnection: false, // CHANGED: Disable auto-reconnection to prevent loops; handle manually if needed
      reconnectionAttempts: 0, // NEW: No attempts
      reconnectionDelay: 2000,
      reconnectionDelayMax: 5000,
      timeout: 20000,
      forceNew: true, // Force a new connection
    });

    // Initialize flags
    socket.isBeingReplaced = false;
    socket.replacementAlertShown = false;

    socket.on('connect', () => {
      console.log(`Socket.IO connected for URL: ${url}, Socket ID: ${socket.id}`);

      // Stop polling if it's running
      if (pollingRef.current) {
        console.log("Stopping polling due to successful Socket.IO connection");
        clearInterval(pollingRef.current);
        pollingRef.current = null;
      }

      // Join the room
      socket.emit('join', { url, token: localStorage.getItem('jwt_token') }, (response) => {
        if (response?.error) {
          console.error('Join error:', response.error);
          setIsLoading(false);
          setVisibleItems([{ ...fallbackItem, content: response.error }]);
        } else {
          console.log('Successfully joined room:', response);
        }
      });
    });

    socket.on('init', (data) => {
      console.log('Received init data:', data);
      handleSocketUpdate(data, 'init');
    });

    socket.on('update', (data) => {
      console.log('Received update data:', data);
      handleSocketUpdate(data, 'update');
    });

    socket.on('delete', (data) => {
      console.log('Received delete data:', data);
      if (data.url === url) {
        // Clear all state
        resetToFallbackState();

        // Show notification
        Swal.fire({
          title: 'URL Deleted',
          text: 'This URL has been deleted and is no longer available.',
          icon: 'info',
          confirmButtonText: 'OK',
        });
      }
    });

    socket.on('session_replaced', (data) => {
      console.log('Session replaced:', data);

      // Prevent reconnection loops by marking this socket as replaced
      socket.isBeingReplaced = true;

      // Clear all state immediately
      resetToFallbackState();

      // NEW: Mark session as inactive to block future connectSocket calls
      setIsSessionActive(false);

      // Show notification only once
      if (!socket.replacementAlertShown) {
        socket.replacementAlertShown = true;

        Swal.fire({
          title: 'Session Replaced',
          text: data.message || 'This URL is now being accessed on another device. Your session has been closed.',
          icon: 'warning',
          confirmButtonText: 'OK',
          allowOutsideClick: false,
          showConfirmButton: true,
          timer: undefined, // Remove any auto-close timer
        }).then(() => {
          // Clean disconnect without triggering reconnection
          if (socket.connected) {
            socket.removeAllListeners();
            socket.disconnect();
          }

          // Clear polling to prevent any restart attempts
          if (pollingRef.current) {
            clearInterval(pollingRef.current);
            pollingRef.current = null;
          }

          console.log('Session replacement handled; no further connections allowed');
        });
      }
    });

    socket.on('error', (error) => {
      console.error('Socket.IO error:', error.message || error);
      setIsLoading(false);
      setVisibleItems([{ ...fallbackItem, content: error.message || 'Connection error occurred' }]);
    });

    socket.on('connect_error', (error) => {
      console.error('Socket.IO connection error:', error.message);

      // Don't start polling if this socket was replaced
      if (socket.isBeingReplaced || !isSessionActive) { // UPDATED: Check persistent flag
        console.log('Socket was replaced or inactive, not starting polling on connect_error');
        return;
      }

      // Start polling as fallback if not already running
      if (!pollingRef.current) {
        console.log("Starting polling due to Socket.IO connection error");
        pollingRef.current = setInterval(() => {
          fetchData('polling');
        }, 30 * 1000);
      }
    });

    socket.on('disconnect', (reason) => {
      console.log('Socket.IO disconnected:', reason);

      // Don't start polling if this socket was replaced or inactive
      if (socket.isBeingReplaced || !isSessionActive) { // UPDATED: Check persistent flag
        console.log('Socket was replaced or inactive, not starting polling');
        return;
      }

      // Start polling if disconnected unexpectedly (not manual)
      if (reason !== 'io client disconnect' && reason !== 'client namespace disconnect' && !pollingRef.current) {
        console.log("Starting polling due to unexpected disconnect");
        pollingRef.current = setInterval(() => {
          fetchData('polling');
        }, 30 * 1000);
      }
    });

    socketRef.current = socket;

    // Cleanup function
    return () => {
      console.log('Cleaning up Socket.IO connection');
      if (socket) {
        socket.removeAllListeners();
        socket.disconnect();
      }
      if (pollingRef.current) {
        console.log("Clearing polling interval");
        clearInterval(pollingRef.current);
        pollingRef.current = null;
      }
    };
  }, [url, handleSocketUpdate, fetchData, isSessionActive]); // UPDATED: Add isSessionActive to dependencies

  // Helper function to reset state (unchanged)
  function resetToFallbackState() {
    setIsEnabled(false);
    setMediaContent([]);
    setVisibleItems([fallbackItem]);
    setAllContent([]);
    setScheduledAt(null);
    setExpiresAt(null);
    setCustomTicker(null);
    setSettings(defaultSettings);
    setIsLoading(false);

    // Clear local storage
    const cacheKey = `preview_${url}`;
    localStorage.removeItem(cacheKey);
    console.log(`Cleared local storage for ${cacheKey}`);
  }


  useEffect(() => {
    const handleMouseMove = () => {
      resetControlTimeout();
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      if (controlTimeoutRef.current) {
        clearTimeout(controlTimeoutRef.current);
      }
    };
  }, [resetControlTimeout]);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        await Promise.all([fetchData('initial'), fetchWeather(), fetchNews()]);
      } catch (error) {
        console.error("Error loading data:", error);
        setVisibleItems([fallbackItem]);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
    const cleanupSocket = connectSocket();
    return cleanupSocket;
  }, [fetchData, fetchWeather, fetchNews, connectSocket]);

  useEffect(() => {
    getUserLocation();
  }, [getUserLocation]);

  useEffect(() => {
    const timer = setInterval(() => {
      if (allContent.length > 0) {
        const newActiveContent = getActiveContent(allContent);
        if (JSON.stringify(newActiveContent) !== JSON.stringify(mediaContent)) {
          setMediaContent(newActiveContent);
          setCurrentIndex(0);
          if (newActiveContent.length > 0) {
            const firstLayout = newActiveContent[0].layout || "single";
            setCurrentLayout(firstLayout);
            const groupedContent = groupMediaByLayout(newActiveContent);
            updateVisibleItems(firstLayout, groupedContent, 0);
          } else {
            console.warn("No new active content, using fallback");
            setVisibleItems([fallbackItem]);
          }
        }
      }
    }, 60000);
    return () => clearInterval(timer);
  }, [allContent, mediaContent, getActiveContent, groupMediaByLayout, updateVisibleItems]);

  useEffect(() => {
    const now = new Date();
    if (scheduledAt && now < scheduledAt) {
      setIsEnabled(false);
      setCountdownType("start");
      const timerInterval = setInterval(() => {
        const currentTime = new Date();
        const timeUntilStart = scheduledAt - currentTime;
        if (timeUntilStart <= 0) {
          setIsEnabled(true);
          setCountdownType(null);
          clearInterval(timerInterval);
          fetchData('schedule-start');
        } else {
          setTimeRemaining(timeUntilStart);
        }
      }, 1000);
      return () => clearInterval(timerInterval);
    } else if (expiresAt && now < expiresAt) {
      setIsEnabled(true);
      setCountdownType("end");
      const timerInterval = setInterval(() => {
        const currentTime = new Date();
        const timeUntilExpiry = expiresAt - currentTime;
        if (timeUntilExpiry <= 0) {
          setIsEnabled(false);
          setCountdownType(null);
          clearInterval(timerInterval);
          fetchData('schedule-end');
        } else {
          setTimeRemaining(timeUntilExpiry);
        }
      }, 1000);
      return () => clearInterval(timerInterval);
    } else if (expiresAt && now >= expiresAt) {
      setIsEnabled(false);
      setCountdownType(null);
    }
    if (!isEnabled && visibleItems.length === 0) {
      console.warn("Preview disabled, using fallback");
      setVisibleItems([fallbackItem]);
    }
  }, [scheduledAt, expiresAt, isEnabled, fetchData]);

  useEffect(() => {
    if (mediaContent.length === 0 || !isEnabled || isPaused) {
      setActiveSlideshow(false);
      if (mediaContent.length === 0 || !isEnabled) {
        setVisibleItems([fallbackItem]);
      }
      return;
    }

    setActiveSlideshow(true);
    const currentItemIndex = currentIndex % mediaContent.length;
    const currentItem = mediaContent[currentItemIndex] || fallbackItem;
    if (
      !currentItem ||
      !Number.isFinite(currentItem.time) ||
      currentItem.time <= 0
    ) {
      console.warn("Invalid current item or time, using fallback", {
        currentIndex,
        item: currentItem,
      });
      setVisibleItems([fallbackItem]);
      return;
    }

    const currentLayout = currentItem.layout || "single";
    setCurrentLayout(currentLayout);
    const layoutConfig =
      layoutOptions.find((option) => option.id === currentLayout) ||
      layoutOptions[0];
    const itemsPerPage = layoutConfig.cols * layoutConfig.rows;
    const delay = currentItem.time * 1000;
    const groupedContent = groupMediaByLayout(mediaContent);
    updateVisibleItems(currentLayout, groupedContent, currentIndex);

    const timer = setTimeout(() => {
      const nextIndex = currentIndex + itemsPerPage;
      if (nextIndex >= mediaContent.length) {
        setCurrentIndex(0);
        const firstLayout = mediaContent[0]?.layout || "single";
        setCurrentLayout(firstLayout);
        updateVisibleItems(firstLayout, groupedContent, 0);
        console.log("Completed one loop, relying on Socket.IO for updates");
      } else {
        setCurrentIndex(nextIndex);
        const nextItem = mediaContent[nextIndex] || fallbackItem;
        const nextLayout = nextItem.layout || "single";
        setCurrentLayout(nextLayout);
        updateVisibleItems(nextLayout, groupedContent, nextIndex);
      }
    }, delay);

    return () => {
      console.log("Clearing slideshow timer");
      clearTimeout(timer);
    };
  }, [
    mediaContent,
    currentIndex,
    isPaused,
    isEnabled,
    groupMediaByLayout,
    updateVisibleItems,
  ]);

  return (
    <div className="relative flex justify-center items-center w-screen h-screen bg-black overflow-hidden">
      {isLoading ? (
        renderFallbackUI(
          "Wait, your content is loading",
          countdownType,
          timeRemaining,
          formatTimeRemaining
        )
      ) : !isEnabled ? (
        renderFallbackUI(
          "This URL is currently inactive.",
          countdownType,
          timeRemaining,
          formatTimeRemaining
        )
      ) : mediaContent.length > 0 ? (
        <div className={`grid w-full h-screen gap-2 ${getGridClasses()}`}>
          {visibleItems.map((item, index) => (
            <div
              key={index}
              className="relative w-full h-full bg-gray-900 rounded overflow-hidden"
            >
              <MediaItem
                content={item}
                index={currentIndex + index}
                isPaused={isPaused}
                setProgress={setProgress}
                getContentUrl={getContentUrl}
                isWebpageUrl={isWebpageUrl}
                videoRefs={videoRefs}
              />
            </div>
          ))}
        </div>
      ) : (
        renderFallbackUI(
          "This URL has no content to display. Please check the URL or content configuration.",
          countdownType,
          timeRemaining,
          formatTimeRemaining
        )
      )}

      {isEnabled && countdownType === "end" && (
        <div className="absolute top-4 right-4 bg-black bg-opacity-50 text-white p-3 rounded-lg backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <FaClock size={20} className="text-red-400" />
            <span className="font-mono">
              {formatTimeRemaining(timeRemaining)}
            </span>
          </div>
        </div>
      )}

      <ClockDisplay
        position={settings.dateTime.position}
        visible={settings.dateTime.visible}
      />

      <TemperatureDisplay
        weather={weather}
        position={settings.temperature.position}
        visible={settings.temperature.visible}
      />

      {(customTicker || news.length > 0) && settings.ticker.visible && (
        <div
          className="absolute bottom-16 left-0 w-full overflow-hidden bg-black bg-opacity-70 py-3"
          style={{
            height: `${settings.ticker.height}px`,
          }}
        >
          <div className="news-ticker-container relative w-full">
            <div
              key={`ticker-${settings.ticker.speed}-${settings.ticker.fontSize}`}
              className="news-ticker"
              style={{
                animationName: "marquee",
                animationDuration: `${customTicker ? settings.ticker.speed * 0.5 : settings.ticker.speed}s`, // Make custom ticker 2x faster
                animationTimingFunction: "linear",
                animationIterationCount: "infinite",
                fontSize: `${settings.ticker.fontSize}px`,
              }}
            >
              {customTicker ? (
                <span className="news-item inline-block px-6 text-white">
                  {customTicker}
                </span>
              ) : (
                <>
                  {news.map((article, index) => (
                    <span
                      key={`news-item-1-${index}`}
                      className="news-item inline-block px-6 text-white"
                    >
                      <strong>{article.title}</strong> -{" "}
                      {formatDescription(article.description)}
                    </span>
                  ))}
                  {news.map((article, index) => (
                    <span
                      key={`news-item-2-${index}`}
                      className="news-item inline-block px-6 text-white"
                    >
                      <strong>{article.title}</strong> -{" "}
                      {formatDescription(article.description)}
                    </span>
                  ))}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {showControls &&
        isEnabled &&
        mediaContent.length > 0 &&
        !isAnyPowerBIContent() && (
          <div className="absolute bottom-28 left-1/2 transform -translate-x-1/2 flex gap-8 z-10">
            <button
              className="bg-gray-900 bg-opacity-80 text-white p-5 rounded-full shadow-xl transition-all duration-300 hover:scale-110 hover:bg-opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                goPrev();
              }}
            >
              <FaChevronLeft size={25} />
            </button>
            <button
              className="bg-gray-900 bg-opacity-80 text-white p-5 rounded-full shadow-xl transition-all duration-300 hover:scale-110 hover:bg-opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                togglePlayPause();
              }}
            >
              {isPaused ? <FaPlay size={25} /> : <FaPause size={25} />}
            </button>
            <button
              className="bg-gray-900 bg-opacity-80 text-white p-5 rounded-full shadow-xl transition-all duration-300 hover:scale-110 hover:bg-opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                goNext();
              }}
            >
              <FaChevronRight size={25} />
            </button>
          </div>
        )}
    </div>
  );
};

export default Preview;